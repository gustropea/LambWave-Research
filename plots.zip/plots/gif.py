import subprocess

paths = ["cubed/nonsubcycle","cubed/subcycle","pillow/nonsubcycle","pillow/subcycle"]
for i in range(0,4):
    for j in range(0,6):
        cmd = "ffmpeg -i "+paths[i]+"/0_"+str(j)+"/0_"+str(j)+".gif -movflags faststart -pix_fmt yuv420p -vf 'scale=trunc(iw/2)*2:trunc(ih/2)*2' "+paths[i]+"/0_"+str(j)+"/0_"+str(j)+".mp4"
        p = subprocess.Popen(str(cmd),stdout=subprocess.PIPE, shell=True)
        p.communicate()
        p.wait()
